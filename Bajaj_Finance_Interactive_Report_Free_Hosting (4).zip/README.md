# Bajaj Finance Interactive Equity Research Report

## Publish for free with GitHub Pages
1. Create a **public** GitHub repository (for example `bajaj-finance-equity-report`).
2. Upload `index.html` from this folder to the repository root. Do **not** upload the audited Excel workbook.
3. Open **Settings → Pages**. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
4. Wait for deployment. Your shareable URL will be `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

## Price refresh behaviour
- The page attempts to load the latest completed daily candle for `BAJFINANCE.NS` from Yahoo Finance's chart endpoint through a public CORS relay.
- It deliberately does not use the in-progress intraday candle. After 15:45 India time, it may accept the current trading day's candle; before then it uses the previous completed close.
- The browser caches the last successful close locally and displays a visible fallback status if the feed fails. The provider and relay are unofficial and can change or stop working; verify the close before relying on it.
- This is a static page, so each visitor's browser refreshes the price. There is no guaranteed central scheduled refresh or server-side uptime.

## Important
GitHub Pages free hosting requires a public repository. Treat the site and its source as public. Publish only the HTML needed to run the report, not the Excel model or private workpapers. This is an educational equity research project, not investment advice.
